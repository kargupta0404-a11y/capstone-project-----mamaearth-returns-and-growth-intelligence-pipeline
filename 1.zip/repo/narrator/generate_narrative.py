"""
Part 3 - GenAI insight narrator (Situation / Complication / Resolution).

Reads narrator/findings.json (written by analysis/clean_and_eda.py) and produces a business
narrative. Two paths, same return shape:
  * online  - Gemini via the google-genai client (needs GEMINI_API_KEY from Google AI Studio's free tier)
  * offline - deterministic f-string template, no network, no key

Usage:
    python narrator/generate_narrative.py                 # auto: Gemini if a key is set, else offline
    python narrator/generate_narrative.py --offline       # force the keyless path
    python narrator/generate_narrative.py --save-sample   # if the LIVE Gemini call succeeds, save
                                                          # narrator/sample_output.txt and check it
"""
import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
FINDINGS_PATH = HERE / "findings.json"
SAMPLE_PATH = HERE / "sample_output.txt"

MODEL = os.environ.get("GEMINI_MODEL", "gemini-flash-lite-latest")
TIMEOUT_MS = 30_000        # 30 s (brief: >= 10 s); google-genai HttpOptions.timeout is in milliseconds
MAX_OUTPUT_TOKENS = 2048   # brief: explicit and >= 300; headroom because some Gemini models count
                           # internal "thinking" tokens against this limit


# --------------------------------------------------------------------------- helpers
def load_findings(path=FINDINGS_PATH):
    with open(path) as f:
        return json.load(f)


def month_name(ym):
    """'2026-03' -> 'March 2026'"""
    return datetime.strptime(ym, "%Y-%m").strftime("%B %Y")


def inr(x):
    return f"INR {x:,.2f}"


SYSTEM_INSTRUCTION = (
    "You are a senior data analyst writing for Mamaearth's regional ops and finance heads. "
    "Write a business narrative of roughly 250 words using EXACTLY three labeled sections, in this "
    "order: 'Situation', 'Complication', 'Resolution'. "
    "Every number you write must come from the findings supplied by the user and appear with the "
    "same value - do not invent, estimate, round differently, or derive any new statistics. "
    "Write in plain business English for readers who will not open a notebook. "
    "The Resolution must contain concrete, actionable recommendations."
)


def build_user_prompt(f):
    """All numbers are interpolated from the findings dict - nothing is hardcoded here."""
    rr = f["return_rate_by_payment"]
    seg = f["highest_risk_segment"]
    peak = f["true_peak_month"]
    infl = f["outlier_inflated_month"]
    return (
        "Verified findings from the Mamaearth returns analysis (use these numbers exactly):\n"
        f"- Cleaned total revenue: {inr(f['cleaned_total_revenue_inr'])} "
        f"(raw total before cleaning: {inr(f['raw_total_revenue_inr'])}).\n"
        f"- The gap of {inr(f['duplicate_reconciliation_delta_inr'])} is entirely due to duplicate "
        "orders caused by a double-submit bug.\n"
        f"- Return rate by payment method: COD {rr['COD']}%, Card {rr['CARD']}%, UPI {rr['UPI']}%.\n"
        f"- Highest-risk segment: {seg['payment_method']} orders in Tier-{seg['city_tier']} cities, "
        f"return rate {seg['return_rate_pct']}%.\n"
        f"- {month_name(infl['month'])} looked like the best month at {inr(infl['apparent_revenue_inr'])}, "
        f"but that was inflated by two bulk orders; corrected it is {inr(infl['corrected_revenue_inr'])}.\n"
        f"- The true peak month is {month_name(peak['month'])} at {inr(peak['revenue_inr'])}.\n\n"
        "Write the Situation, Complication and Resolution narrative now."
    )


# --------------------------------------------------------------------------- online path
def generate_scr_narrative(findings: dict, fallback: bool = True) -> dict:
    """
    Online path (Gemini). Returns {"status","narrative","tokens"} on success and
    {"status":"error","narrative":None,"message":...} on failure - never a raw exception.
    If fallback=True and there is no API key or the call fails, the offline template is returned
    instead (with 'fallback_reason' explaining why), so the pipeline always yields a narrative.
    """
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        if fallback:
            res = generate_scr_narrative_offline(findings)
            res["fallback_reason"] = "no GEMINI_API_KEY set"
            return res
        return {"status": "error", "narrative": None, "message": "no GEMINI_API_KEY set"}

    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=TIMEOUT_MS))
        response = client.models.generate_content(
            model=MODEL,
            contents=build_user_prompt(findings),
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION,
                # temperature=0.0: this is a factual finance/ops report, not creative writing -
                # we want the most deterministic, least embellished output so numbers are not "reinterpreted".
                temperature=0.0,
                max_output_tokens=MAX_OUTPUT_TOKENS,
            ),
        )
        text = (response.text or "").strip()
        if not text:
            raise ValueError("Gemini returned an empty response")
        usage = getattr(response, "usage_metadata", None)
        tokens = getattr(usage, "total_token_count", None)
        return {"status": "success", "narrative": text, "tokens": tokens, "source": f"gemini:{MODEL}"}
    except Exception as err:  # noqa: BLE001 - caller must never see a raw exception
        if fallback:
            res = generate_scr_narrative_offline(findings)
            res["fallback_reason"] = f"Gemini call failed: {err}"
            return res
        return {"status": "error", "narrative": None, "message": str(err)}


# --------------------------------------------------------------------------- offline path
def generate_scr_narrative_offline(findings: dict) -> dict:
    """Deterministic, keyless, network-free SCR narrative built straight from the findings."""
    rr = findings["return_rate_by_payment"]
    seg = findings["highest_risk_segment"]
    peak = findings["true_peak_month"]
    infl = findings["outlier_inflated_month"]

    situation = (
        f"After cleaning, Mamaearth's order book totals {inr(findings['cleaned_total_revenue_inr'])}. "
        f"The raw extract showed {inr(findings['raw_total_revenue_inr'])}; the "
        f"{inr(findings['duplicate_reconciliation_delta_inr'])} difference is entirely duplicate orders "
        f"created by a double-submit bug, not a real revenue change. The true sales peak is "
        f"{month_name(peak['month'])} at {inr(peak['revenue_inr'])}, not "
        f"{month_name(infl['month'])} as the raw numbers suggested."
    )
    complication = (
        f"Returns are concentrated in cash-on-delivery. COD orders are returned {rr['COD']}% of the time, "
        f"against {rr['UPI']}% for UPI and {rr['CARD']}% for Card. The problem is sharpest in one segment: "
        f"{seg['payment_method']} orders in Tier-{seg['city_tier']} cities return at {seg['return_rate_pct']}%, "
        f"so the blended COD figure hides where the losses sit. Separately, {month_name(infl['month'])} "
        f"looked strongest at {inr(infl['apparent_revenue_inr'])} only because two bulk orders landed "
        f"in it; excluding them it is {inr(infl['corrected_revenue_inr'])}."
    )
    resolution = (
        f"1) Target {seg['payment_method']} in Tier-{seg['city_tier']} cities first: require order "
        f"confirmation or a small prepaid advance before dispatch. 2) Nudge COD customers toward UPI or Card "
        f"with prepaid incentives, since those channels return at {rr['UPI']}% and {rr['CARD']}%. "
        f"3) Fix the double-submit bug so duplicate orders stop inflating reported revenue. "
        f"4) Plan inventory and campaigns around {month_name(peak['month'])}, the genuine peak, and "
        f"report bulk orders separately so they do not distort monthly trends."
    )
    narrative = f"Situation\n{situation}\n\nComplication\n{complication}\n\nResolution\n{resolution}"
    return {"status": "success", "narrative": narrative, "tokens": None, "source": "offline-template"}


# --------------------------------------------------------------------------- accuracy checker
def check_figures(narrative: str, findings: dict = None, verbose: bool = True) -> bool:
    """Assert the five required figures appear (commas normalised). Prints a pass/fail line each."""
    text = narrative.replace(",", "")
    checks = [
        ("cleaned total revenue 97,358.30", "97358.3"),
        ("COD return rate 44.4", "44.4"),
        ("highest-risk segment rate 54.5", "54.5"),
        ("duplicate delta 2,501.90", "2501.9"),
        ("true peak month: March", "March"),
        ("true peak revenue 20,318.90", "20318.9"),
    ]
    all_ok = True
    for label, needle in checks:
        ok = needle in text
        all_ok &= ok
        if verbose:
            print(f"  [{'PASS' if ok else 'FAIL'}] {label}")
    return all_ok


# --------------------------------------------------------------------------- CLI
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--offline", action="store_true", help="force the keyless offline template")
    ap.add_argument("--save-sample", action="store_true",
                    help="save a successful LIVE Gemini output to narrator/sample_output.txt")
    args = ap.parse_args()

    findings = load_findings()
    result = (generate_scr_narrative_offline(findings) if args.offline
              else generate_scr_narrative(findings))

    print(f"Path used : {result.get('source')}")
    if result.get("fallback_reason"):
        print(f"Fallback  : {result['fallback_reason']}")
    print(f"Status    : {result['status']}   tokens: {result.get('tokens')}\n")
    print(result["narrative"] or result.get("message"))
    print("\nNumeric accuracy check:")
    ok = check_figures(result["narrative"], findings) if result["narrative"] else False

    if args.save_sample:
        if str(result.get("source", "")).startswith("gemini"):
            SAMPLE_PATH.write_text(result["narrative"] + "\n")
            print(f"\nSaved live Gemini output to {SAMPLE_PATH.name}")
        else:
            print("\n--save-sample ignored: this run did not come from the live Gemini API "
                  "(set GEMINI_API_KEY and rerun).")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
