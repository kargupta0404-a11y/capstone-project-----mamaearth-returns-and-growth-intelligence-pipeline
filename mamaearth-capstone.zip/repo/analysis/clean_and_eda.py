"""
Part 2 - Python/Pandas data wrangling & EDA for the Mamaearth returns pipeline.

Run from anywhere:  python analysis/clean_and_eda.py
Reads the RAW CSVs in data/ (never edited by hand), prints every intermediate result the
brief asks for, and (Part 3, Task 1) writes narrator/findings.json at the very end.

The core steps are plain functions so analysis/visualize.py can re-use exactly the same
logic and regenerate identical numbers from the raw files.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
FINDINGS_PATH = ROOT / "narrator" / "findings.json"


# --------------------------------------------------------------------------- helpers
def load_raw():
    orders = pd.read_csv(DATA / "orders.csv")
    customers = pd.read_csv(DATA / "customers.csv")
    products = pd.read_csv(DATA / "products.csv")
    return orders, customers, products


def standardize_payment(orders):
    out = orders.copy()
    out["payment_method"] = out["payment_method"].str.strip().str.upper()
    return out


DEDUP_KEY = ["customer_id", "product_id", "order_date", "quantity",
             "discount_pct", "payment_method", "rating", "returned"]


def drop_duplicates(orders):
    """Return (clean_frame, dropped_frame). order_id is excluded from the key on purpose."""
    dup_mask = orders.duplicated(subset=DEDUP_KEY, keep="first")
    return orders[~dup_mask].copy(), orders[dup_mask].copy()


def add_order_value(orders, products, customers):
    merged = (orders.merge(products, on="product_id", how="left", validate="m:1")
                    .merge(customers, on="customer_id", how="left", validate="m:1"))
    merged["order_value"] = merged["quantity"] * merged["price"] * (1 - merged["discount_pct"] / 100)
    return merged


def iqr_bounds(series):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    return q1, q3, iqr, q1 - 1.5 * iqr, q3 + 1.5 * iqr


def build_pipeline():
    """Quiet end-to-end computation used by visualize.py. Returns a dict of results."""
    raw_orders, customers, products = load_raw()
    orders = standardize_payment(raw_orders)
    orders, dropped = drop_duplicates(orders)
    orders["discount_pct"] = orders["discount_pct"].fillna(0)
    orders["rating"] = orders["rating"].fillna(orders["rating"].median())
    merged = add_order_value(orders, products, customers)
    _, _, _, lower, upper = iqr_bounds(merged["quantity"])
    merged["is_outlier"] = (merged["quantity"] < lower) | (merged["quantity"] > upper)
    merged["order_date"] = pd.to_datetime(merged["order_date"])
    merged["year_month"] = merged["order_date"].dt.to_period("M").astype(str)
    return {
        "merged": merged,
        "return_by_payment": merged.groupby("payment_method")["returned"].mean().mul(100).round(1),
        "monthly_all": merged.groupby("year_month")["order_value"].sum().round(2),
        "monthly_corrected": merged[~merged["is_outlier"]].groupby("year_month")["order_value"].sum().round(2),
    }


def strength(r):
    a = abs(r)
    if a < 0.2:
        return "negligible"
    if a < 0.4:
        return "weak"
    if a < 0.7:
        return "moderate"
    return "strong"


def banner(text):
    print("\n" + "=" * 78 + f"\n{text}\n" + "=" * 78)


# --------------------------------------------------------------------------- main
def main():
    pd.set_option("display.width", 140)
    pd.set_option("display.max_columns", 30)

    # ---- Task 1: load and inspect
    banner("TASK 1 - Load and inspect")
    orders, customers, products = load_raw()
    print("orders.shape    :", orders.shape)
    print("customers.shape :", customers.shape)
    print("products.shape  :", products.shape)
    assert orders.shape == (180, 9)

    # ---- Task 2: standardize payment_method
    banner("TASK 2 - Standardize payment_method casing")
    print("BEFORE unique values (%d):" % orders["payment_method"].nunique(),
          list(orders["payment_method"].unique()))
    orders = standardize_payment(orders)
    print("AFTER  unique values (%d):" % orders["payment_method"].nunique(),
          list(orders["payment_method"].unique()))
    print("Counts after fix (raw 180 rows):")
    print(orders["payment_method"].value_counts().to_string())

    # ---- Task 3: duplicates
    banner("TASK 3 - Remove duplicate orders")
    orders_clean, dropped = drop_duplicates(orders)
    print("Duplicates flagged:", len(dropped))
    print("Dropped order_ids :", list(dropped["order_id"]))
    print("orders_clean.shape:", orders_clean.shape)
    assert orders_clean.shape == (175, 9)

    # ---- Task 4: impute
    banner("TASK 4 - Impute missing values (on the de-duplicated frame)")
    n_disc = int(orders_clean["discount_pct"].isna().sum())
    n_rate = int(orders_clean["rating"].isna().sum())
    median_rating = orders_clean["rating"].median()
    print(f"discount_pct NaN rows: {n_disc}  -> filled with 0 (business rule: no promo code)")
    print(f"median of non-null ratings (before imputing): {median_rating}")
    print(f"rating NaN rows: {n_rate}  -> filled with median {median_rating}")
    orders_clean["discount_pct"] = orders_clean["discount_pct"].fillna(0)
    orders_clean["rating"] = orders_clean["rating"].fillna(median_rating)
    print("Remaining nulls:", orders_clean[["discount_pct", "rating"]].isnull().sum().to_dict())

    # ---- Task 5: merge and reconcile
    banner("TASK 5 - Merge and reconcile against Part 1 (SQL Report a)")
    merged = add_order_value(orders_clean, products, customers)
    cleaned_total = round(merged["order_value"].sum(), 2)
    print(f"merged.shape: {merged.shape}")
    print(f"Cleaned total order_value (175 rows): INR {cleaned_total:,.2f}")

    # Independent check: value of the 5 dropped rows (their discounts are already non-null here,
    # but use fillna(0) so the check mirrors the SQL COALESCE rule exactly).
    dropped_valued = add_order_value(dropped.assign(discount_pct=dropped["discount_pct"].fillna(0)),
                                     products, customers)
    dropped_value = round(dropped_valued["order_value"].sum(), 2)
    raw_total_sql = 99860.20  # SQL Report (a) on the raw 180 rows
    raw_total_py = round(add_order_value(
        standardize_payment(load_raw()[0]).assign(
            discount_pct=lambda d: d["discount_pct"].fillna(0)), products, customers)["order_value"].sum(), 2)
    delta = round(raw_total_py - cleaned_total, 2)
    print(f"Raw total recomputed in pandas over 180 rows: INR {raw_total_py:,.2f} (SQL Report a: {raw_total_sql:,.2f})")
    print(f"Delta raw - cleaned            : INR {delta:,.2f}")
    print(f"Sum of the 5 dropped rows      : INR {dropped_value:,.2f}")
    assert abs(raw_total_py - raw_total_sql) < 0.005
    assert abs(delta - dropped_value) < 0.005
    print("\nRECONCILIATION NOTE:")
    print(f"  The pandas total of INR {cleaned_total:,.2f} is INR {delta:,.2f} lower than the raw SQL total of "
          f"INR {raw_total_sql:,.2f}. That entire gap is explained by the 5 duplicate orders "
          f"({', '.join(dropped['order_id'])}) removed in Task 3 - a double-submit bug - whose combined "
          f"order_value is INR {dropped_value:,.2f}, summed independently above. It is NOT caused by imputation: "
          f"filling discount_pct with 0 matches SQL's COALESCE(discount_pct, 0), and filling rating touches no "
          f"revenue figure, so neither step changes any order_value total.")

    # ---- Task 6: IQR outliers
    banner("TASK 6 - IQR outlier detection on quantity")
    q1, q3, iqr, lower, upper = iqr_bounds(merged["quantity"])
    print(f"Q1={q1}  Q3={q3}  IQR={iqr}  lower={lower}  upper={upper}")
    merged["is_outlier"] = (merged["quantity"] < lower) | (merged["quantity"] > upper)
    print(f"Outlier rows flagged (kept in the dataset): {int(merged['is_outlier'].sum())}")
    print(merged.loc[merged["is_outlier"], ["order_id", "customer_id", "product_id", "order_date",
                                            "quantity", "order_value"]].to_string(index=False))

    # ---- Task 7: hypothesis, COD return rate
    banner("TASK 7 - Hypothesis: COD orders have a higher return rate than Card/UPI")
    print("HYPOTHESIS: Cash-on-Delivery orders are returned more often than prepaid (Card/UPI) orders.")
    by_pay = merged.groupby("payment_method")["returned"].agg(["count", "mean"])
    by_pay["return_rate_pct"] = (by_pay["mean"] * 100).round(1)
    print(by_pay.to_string())
    rates = by_pay["return_rate_pct"].to_dict()
    verdict = "Confirmed" if rates["COD"] > max(rates["CARD"], rates["UPI"]) else "Rejected"
    print(f"VERDICT: {verdict} - COD {rates['COD']}% vs CARD {rates['CARD']}% and UPI {rates['UPI']}%.")

    # ---- Task 8: segmentation
    banner("TASK 8 - Multi-level segmentation: payment_method x city_tier")
    seg = merged.groupby(["payment_method", "city_tier"])["returned"].agg(["count", "mean"])
    seg["return_rate_pct"] = (seg["mean"] * 100).round(1)
    print(seg.to_string())
    top = seg["return_rate_pct"].idxmax()
    top_rate = float(seg.loc[top, "return_rate_pct"])
    print(f"\nHIGHEST-RISK SEGMENT: {top[0]} + Tier-{top[1]} cities at {top_rate}% "
          f"({int(seg.loc[top, 'count'])} orders).")
    cod1, cod2 = seg.loc[("COD", 1)], seg.loc[("COD", 2)]
    print(f"COD risk is not uniform: Tier-1 COD {int(cod1['count'])} orders at {cod1['return_rate_pct']}% "
          f"vs Tier-2 COD {int(cod2['count'])} orders at {cod2['return_rate_pct']}%. "
          f"The blended COD rate of {rates['COD']}% hides where the problem is concentrated.")

    # ---- Task 9: correlation
    banner("TASK 9 - Correlation analysis")
    cols = ["rating", "returned", "discount_pct", "quantity"]
    corr = merged[cols].corr()
    print(corr.round(3).to_string())
    print("\nPairwise strength (bands: <0.2 negligible, 0.2-0.39 weak, 0.4-0.69 moderate, >=0.7 strong):")
    for i, a in enumerate(cols):
        for b in cols[i + 1:]:
            r = corr.loc[a, b]
            print(f"  {a:>13} vs {b:<13} r = {r:+.3f}  -> {strength(r)}")
    r_dr = corr.loc["discount_pct", "returned"]
    print(f"\nHYPOTHESIS 'higher discounts reduce returns': discount_pct vs returned r = {r_dr:+.3f} "
          f"({strength(r_dr)}) -> Busted.")

    # ---- Task 10: time series
    banner("TASK 10 - Outlier-corrected monthly revenue")
    merged["order_date"] = pd.to_datetime(merged["order_date"])
    merged["year_month"] = merged["order_date"].dt.to_period("M").astype(str)
    monthly_all = merged.groupby("year_month")["order_value"].sum().round(2)
    monthly_fix = merged[~merged["is_outlier"]].groupby("year_month")["order_value"].sum().round(2)
    print("(1) INCLUDING the 2 outlier orders:")
    print(monthly_all.to_string())
    print("\n(2) EXCLUDING the 2 outlier orders (outlier-corrected):")
    print(monthly_fix.to_string())
    apparent_peak, true_peak = monthly_all.idxmax(), monthly_fix.idxmax()
    print(f"\nJanuary's apparent lead is an artifact: the two bulk orders O0011 (2026-01-28) and O0098 "
          f"(2026-01-10) both landed in January and inflate it from INR {monthly_fix['2026-01']:,.2f} to "
          f"INR {monthly_all['2026-01']:,.2f}. Once excluded, March ({true_peak}) is the genuine peak month "
          f"at INR {monthly_fix[true_peak]:,.2f}.")
    assert apparent_peak == "2026-01" and true_peak == "2026-03"

    # ---- Part 3, Task 1: findings.json (never hand-typed)
    banner("EXPORT - narrator/findings.json")
    findings = {
        "cleaned_total_revenue_inr": cleaned_total,
        "raw_total_revenue_inr": raw_total_sql,
        "duplicate_reconciliation_delta_inr": delta,
        "return_rate_by_payment": {k: float(rates[k]) for k in ["COD", "CARD", "UPI"]},
        "highest_risk_segment": {"payment_method": top[0], "city_tier": int(top[1]),
                                 "return_rate_pct": top_rate},
        "true_peak_month": {"month": true_peak, "revenue_inr": float(monthly_fix[true_peak])},
        "outlier_inflated_month": {"month": apparent_peak,
                                   "apparent_revenue_inr": float(monthly_all[apparent_peak]),
                                   "corrected_revenue_inr": float(monthly_fix[apparent_peak])},
    }
    FINDINGS_PATH.parent.mkdir(exist_ok=True)
    FINDINGS_PATH.write_text(json.dumps(findings, indent=2) + "\n")
    print(json.dumps(findings, indent=2))
    print(f"\nWritten to {FINDINGS_PATH.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
