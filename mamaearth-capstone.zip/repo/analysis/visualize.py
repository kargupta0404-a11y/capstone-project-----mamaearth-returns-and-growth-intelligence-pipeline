"""
Part 2, Task 11 - two Matplotlib charts, regenerated from the raw CSVs every run.

Run AFTER (or independently of) clean_and_eda.py:  python analysis/visualize.py
It re-uses build_pipeline() from clean_and_eda.py, so there is one source of truth for the numbers.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # headless-safe
import matplotlib.pyplot as plt

from clean_and_eda import build_pipeline

OUT = Path(__file__).resolve().parent.parent / "visualizations"
OUT.mkdir(exist_ok=True)

MONTH_NAMES = {"01": "January", "02": "February", "03": "March",
               "04": "April", "05": "May", "06": "June"}


def plot_return_rate(rates):
    rates = rates.sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(7, 5))
    colors = ["#c0392b" if m == rates.index[0] else "#7f8c8d" for m in rates.index]
    bars = ax.bar(rates.index, rates.values, color=colors)
    for bar, val in zip(bars, rates.values):
        ax.text(bar.get_x() + bar.get_width() / 2, val + 0.8, f"{val:.1f}%",
                ha="center", va="bottom", fontweight="bold")
    multiple = rates["COD"] / rates["CARD"]
    ax.set_title(f"COD Returns at {rates['COD']:.1f}% - {multiple:.0f}x Card ({rates['CARD']:.1f}%)")
    ax.set_xlabel("Payment method (cleaned)")
    ax.set_ylabel("Return rate (%)")
    ax.set_ylim(0, rates.max() * 1.18)
    fig.tight_layout()
    fig.savefig(OUT / "return_rate_by_payment.png", dpi=150)
    plt.close(fig)


def plot_monthly_revenue(monthly_corrected):
    labels = [MONTH_NAMES[m[-2:]] for m in monthly_corrected.index]
    peak = monthly_corrected.idxmax()
    peak_name = MONTH_NAMES[peak[-2:]]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(labels, monthly_corrected.values, marker="o", linewidth=2, color="#2c3e50")
    ax.scatter([peak_name], [monthly_corrected[peak]], s=140, color="#c0392b", zorder=3)
    ax.annotate(f"Peak: INR {monthly_corrected[peak]:,.2f}", (peak_name, monthly_corrected[peak]),
                textcoords="offset points", xytext=(0, 12), ha="center", fontweight="bold")
    ax.set_title(f"Outlier-Corrected Monthly Revenue - {peak_name} 2026 Is the True Peak")
    ax.set_xlabel("Month (2026)")
    ax.set_ylabel("Revenue (INR)")
    ax.set_ylim(0, monthly_corrected.max() * 1.18)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT / "monthly_revenue_trend.png", dpi=150)
    plt.close(fig)


def main():
    res = build_pipeline()
    print("Return rate by payment (%):", res["return_by_payment"].to_dict())
    print("Outlier-corrected monthly revenue:", res["monthly_corrected"].to_dict())
    plot_return_rate(res["return_by_payment"])
    plot_monthly_revenue(res["monthly_corrected"])
    print("Saved:", *(p.name for p in sorted(OUT.glob("*.png"))))


if __name__ == "__main__":
    main()
