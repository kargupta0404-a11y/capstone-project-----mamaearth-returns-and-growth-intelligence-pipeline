-- Part 1, Task 3: reports (run against the RAW, uncleaned data loaded by seed_data.sql)
-- Run order: schema.sql -> seed_data.sql -> reports.sql (on a freshly built database:
-- report i) uses ALTER TABLE ADD COLUMN, which fails if executed twice on the same DB).
-- The output of every query is pasted as a comment directly above it.

-- ==========================================================================
-- a) Order totals (NULL discount treated as 0%)  [2 marks]
-- OUTPUT:
--   total_orders | total_revenue | avg_order_value
--   -------------+---------------+----------------
--   180          | 99860.2       | 554.78         
--   (1 row)
-- ==========================================================================
SELECT COUNT(*)                     AS total_orders,
       ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2)         AS total_revenue,
       ROUND(AVG(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2)         AS avg_order_value
FROM orders o
JOIN products p ON o.product_id = p.product_id;

-- ==========================================================================
-- b) COUNT(*) vs COUNT(column)  [2 marks]
-- OUTPUT:
--   total_rows | rated_rows | unrated_rows
--   -----------+------------+-------------
--   180        | 165        | 15          
--   (1 row)
-- ==========================================================================
SELECT COUNT(*)                   AS total_rows,
       COUNT(rating)                AS rated_rows,
       COUNT(*) - COUNT(rating)     AS unrated_rows
FROM orders;

-- ==========================================================================
-- c1) LEFT JOIN + HAVING: customers with zero orders  [3 marks (part 1 of 2)]
-- OUTPUT:
--   customer_id | name  
--   ------------+-------
--   C045        | Vihaan
--   (1 row)
-- ==========================================================================
SELECT c.customer_id, c.name
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
HAVING COUNT(o.order_id) = 0;

-- ==========================================================================
-- c2) Independent cross-check with NOT IN (must match c1)  [3 marks (part 2 of 2)]
-- OUTPUT:
--   customer_id | name  
--   ------------+-------
--   C045        | Vihaan
--   (1 row)
-- ==========================================================================
SELECT customer_id, name
FROM customers
WHERE customer_id NOT IN (SELECT DISTINCT customer_id FROM orders);

-- ==========================================================================
-- d) GROUP BY + HAVING: cities with return rate > 20%  [3 marks]
-- OUTPUT:
--   city      | total_orders | returned_orders | return_rate_pct
--   ----------+--------------+-----------------+----------------
--   Jaipur    | 19           | 8               | 42.1           
--   Lucknow   | 49           | 15              | 30.6           
--   Bangalore | 33           | 8               | 24.2           
--   (3 rows)
-- ==========================================================================
SELECT c.city,
       COUNT(*)                                   AS total_orders,
       SUM(o.returned)                            AS returned_orders,
       ROUND(100.0 * SUM(o.returned) / COUNT(*), 1) AS return_rate_pct
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY c.city
HAVING return_rate_pct > 20
ORDER BY return_rate_pct DESC;

-- ==========================================================================
-- e1) Top 5 customers by spend  [3 marks (part 1 of 2)]
-- OUTPUT:
--   customer_id | name    | total_spend
--   ------------+---------+------------
--   C043        | Reyansh | 12920.0    
--   C026        | Isha    | 8371.6     
--   C008        | Meera   | 4564.6     
--   C011        | Arjun   | 4111.0     
--   C042        | Sanya   | 3785.0     
--   (5 rows)
-- ==========================================================================
-- Tie-break on customer_id ASC: without it, customers with equal spend can swap
-- places between runs, which would make LIMIT/OFFSET pagination unstable.
SELECT c.customer_id, c.name,
       ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2) AS total_spend
FROM orders o
JOIN products p  ON o.product_id  = p.product_id
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_spend DESC, c.customer_id ASC
LIMIT 5;

-- ==========================================================================
-- e2) Ranks 3-5 via LIMIT 3 OFFSET 2 (same ordering, incl. tie-break)  [3 marks (part 2 of 2)]
-- OUTPUT:
--   customer_id | name  | total_spend
--   ------------+-------+------------
--   C008        | Meera | 4564.6     
--   C011        | Arjun | 4111.0     
--   C042        | Sanya | 3785.0     
--   (3 rows)
-- ==========================================================================
SELECT c.customer_id, c.name,
       ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2) AS total_spend
FROM orders o
JOIN products p  ON o.product_id  = p.product_id
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_spend DESC, c.customer_id ASC
LIMIT 3 OFFSET 2;

-- ==========================================================================
-- f) Three-table JOIN + GROUP BY: revenue by category  [3 marks]
-- OUTPUT:
--   category     | order_count | category_revenue
--   -------------+-------------+-----------------
--   Haircare     | 54          | 44956.1         
--   Skincare     | 60          | 27346.0         
--   Babycare     | 30          | 16805.0         
--   PersonalCare | 36          | 10753.1         
--   (4 rows)
-- ==========================================================================
SELECT p.category,
       COUNT(*)                AS order_count,
       ROUND(SUM(o.quantity * p.price * (1 - COALESCE(o.discount_pct, 0) / 100.0)), 2)    AS category_revenue
FROM orders o
JOIN products p  ON o.product_id  = p.product_id
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY p.category
ORDER BY category_revenue DESC;

-- ==========================================================================
-- g) LIKE: customers whose name starts with 'A'  [2 marks]
-- OUTPUT:
--   customer_id | name  
--   ------------+-------
--   C001        | Aarav 
--   C003        | Aditi 
--   C004        | Ananya
--   C011        | Arjun 
--   C021        | Aryan 
--   C030        | Anika 
--   C031        | Aditya
--   C036        | Aisha 
--   C041        | Ayaan 
--   C044        | Aria  
--   (10 rows)
-- ==========================================================================
SELECT customer_id, name
FROM customers
WHERE name LIKE 'A%'
ORDER BY customer_id;

-- ==========================================================================
-- h) DISTINCT acquisition sources  [1 mark]
-- OUTPUT:
--   acquisition_source
--   ------------------
--   Ad                
--   Organic           
--   Referral          
--   Social            
--   (4 rows)
-- ==========================================================================
SELECT DISTINCT acquisition_source
FROM customers
ORDER BY acquisition_source;

-- ==========================================================================
-- i) ALTER TABLE + UPDATE with CASE (no WHERE: every row gets a tier)  [1 mark]
-- OUTPUT of the verification query below:
--   loyalty_tier | customers
--   -------------+----------
--   Gold         | 28       
--   Silver       | 17       
--   (2 rows)
-- ==========================================================================
ALTER TABLE customers ADD COLUMN loyalty_tier VARCHAR(10);
UPDATE customers
SET loyalty_tier = CASE WHEN city_tier = 1 THEN 'Gold' ELSE 'Silver' END;

SELECT loyalty_tier, COUNT(*) AS customers
FROM customers
GROUP BY loyalty_tier
ORDER BY loyalty_tier;
