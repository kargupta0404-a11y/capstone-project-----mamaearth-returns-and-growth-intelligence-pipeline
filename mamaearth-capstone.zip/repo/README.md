# Mamaearth Returns & Growth Intelligence Pipeline

Three connected layers that prove, end to end, where returns are eating into Mamaearth's margins:

```
data/*.csv ──► SQL layer ──► (reconciles with) ──► Python analysis ──► findings.json ──► GenAI narrator
 (raw, never    sql/         Report (a) total       analysis/         narrator/         narrator/
  hand-edited)  reports.sql  ₹99,860.20             clean_and_eda.py  findings.json     generate_narrative.py
```

No layer reports a number it did not compute itself or receive from the layer before it.

## Repository structure

```
├── README.md
├── requirements.txt
├── sql/
│   ├── schema.sql              # 3 tables (customers, products, orders); drops + recreates them
│   ├── seed_data.sql           # INSERTs generated from data/*.csv (blank cells -> NULL)
│   └── reports.sql             # 9 reports (a-i), output pasted as a comment above each query
├── data/
│   ├── customers.csv           # 45 rows  ┐
│   ├── products.csv            # 16 rows  ├ provided data, committed exactly as given
│   └── orders.csv              # 180 rows ┘
├── analysis/
│   ├── clean_and_eda.py        # Part 2: cleaning + EDA; last step writes narrator/findings.json
│   └── visualize.py            # Part 2 Task 11: two PNG charts
├── visualizations/
│   ├── return_rate_by_payment.png
│   └── monthly_revenue_trend.png
└── narrator/
    ├── findings.json           # machine-written by clean_and_eda.py (never hand-typed)
    ├── generate_narrative.py   # Gemini SCR narrative + offline fallback + numeric checker
    └── sample_output.txt       # saved live-Gemini output that the checker was run against
```

## How to run (in this order)

Requirements: Python 3.10+ and `pip install -r requirements.txt`. SQLite ships with Python.

### 1. SQL layer (Part 1)

Using the `sqlite3` CLI:

```bash
sqlite3 mamaearth.db < sql/schema.sql
sqlite3 mamaearth.db < sql/seed_data.sql
sqlite3 mamaearth.db < sql/reports.sql
```

No `sqlite3` CLI? Same thing from Python:

```bash
python -c "import sqlite3; c=sqlite3.connect('mamaearth.db'); [c.executescript(open(f'sql/{f}.sql').read()) for f in ('schema','seed_data')]"
```

Then check `SELECT COUNT(*)` on the three tables: **45 / 16 / 180**.
`reports.sql` runs on the raw, uncleaned data and contains the expected output above every query.
Run it against a freshly built database: report (i) uses `ALTER TABLE ... ADD COLUMN`, which cannot be
executed twice (re-running `schema.sql` + `seed_data.sql` first resets everything).

**Output flow:** Report (a) gives the raw revenue total, **₹99,860.20**. Part 2 reconciles its own total against this number.

### 2. Python analysis layer (Part 2)

```bash
python analysis/clean_and_eda.py
python analysis/visualize.py
```

`clean_and_eda.py` reads the raw CSVs directly (not the SQL database), so Part 1 and Part 2 can be run in either
order. It prints every intermediate result: 7 -> 3 payment spellings, 5 duplicates dropped (O0176-O0180),
imputations, the ₹97,358.30 total and the reconciliation note attributing the ₹2,501.90 gap to the duplicates,
IQR outliers (O0011, O0098), COD return rate, COD + Tier-2 segment, correlations, and outlier-corrected monthly revenue.

**Output flow:** the last step of `clean_and_eda.py` (Part 3, Task 1) **writes `narrator/findings.json`**, so the narrator can
never drift from these numbers. `visualize.py` re-uses the same pipeline and writes both PNGs to `visualizations/`.

### 3. GenAI narrator (Part 3)

**Without any API key (offline, fully deterministic, zero configuration):**

```bash
python narrator/generate_narrative.py
```

With no key, the script automatically falls back to the offline template, or force it with `--offline`.

**With Gemini (free tier):** create a free key in [Google AI Studio](https://aistudio.google.com/apikey), then

```bash
export GEMINI_API_KEY="your-key"          # Windows PowerShell:  $env:GEMINI_API_KEY="your-key"
python narrator/generate_narrative.py --save-sample
```

`--save-sample` writes the live Gemini output to `narrator/sample_output.txt` and runs the numeric checker on it.
The model defaults to `gemini-2.5-flash` and can be changed with `GEMINI_MODEL`. If the API call fails
for any reason (bad key, quota, timeout), the script falls back to the offline template and says why; it never
crashes with a raw exception.

Both paths run the checker, which prints PASS/FAIL for the five required figures: 97,358.30, 44.4, 54.5, 2,501.90, and
March with 20,318.90.

## Key results (all reproducible by the steps above)

| Finding | Value |
|---|---|
| Raw revenue (SQL) / cleaned revenue (pandas) | ₹99,860.20 / ₹97,358.30 |
| Gap | ₹2,501.90, exactly the 5 duplicate orders |
| Return rate: COD / UPI / Card | 44.4% / 18.9% / 14.7% |
| Highest-risk segment | COD + Tier-2 cities, 54.5% (Tier-1 COD: 37.5%) |
| Discount vs returns | r = -0.09 (negligible) - "discounts reduce returns" is busted |
| True peak month | March 2026, ₹20,318.90 (January's ₹29,582.10 is inflated by two bulk orders) |

## Design notes

- **Cleaning lives only in code.** The CSVs are never edited; the SQL layer loads them raw and Part 2 cleans them.
- **Duplicates are detected on every column except `order_id`**, because a double-submit bug produces a new ID for the same order.
- **Outliers are flagged, not dropped** (`is_outlier`), so the time series can be shown both ways.
- **`temperature=0.0`** for the Gemini call because this is a factual business report, not creative writing.
